export default function Page() {
  return <div className='p-4'>This is the Find Shift page</div>;
}